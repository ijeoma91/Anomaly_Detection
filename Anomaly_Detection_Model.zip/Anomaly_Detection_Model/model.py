import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
import pickle



#Let's load our dataset as csv file from our desktop

Anomaly = pd.read_csv("dataset_final.csv")
print(Anomaly.head())

# Let's drop the column which we are not using for the project

Anomaly.drop("Time", axis=1)
Anomaly_df = Anomaly
print(Anomaly_df.head())


X = Anomaly_df.values
print(X)

# Let's plot our dataset using the scatter plot

plt.scatter(X[:, 0], X[:,1])
plt.show()


# let train our model using one the best algorithms for anomaly detection

classifier = IsolationForest(contamination=0.1, max_samples="auto", n_estimators=50)
classifier.fit(X)
prediction = classifier.predict(X)

# Make pickle file for our model

pickle.dump(classifier, open("model.pkl", "wb"))